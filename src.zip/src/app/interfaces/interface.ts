export interface RespuestaToHeadLines{
    data: Data[];
}

export interface Data {
    date: Date;
    title: string;
    extra: string;
}
